SMSEvent.addListener(StrandMap,"onload", setUpStrandMap);

function setUpStrandMap() {
	StrandMap.enableMisconceptions(true);
	infoBubble = StrandMap.getInfoBubble();	
	SMSEvent.addListener(StrandMap,"onbenchmarkselect",onBenchmarkSelect);
	infoBubble.setMaxSize(375,350);	
	infoBubble.addBuiltinTab("nses","NSES Standards");
	infoBubble.addBuiltinTab("relatedbenchmarks","Related Benchmarks");
}
function onBenchmarkSelect() {
	infoBubble.setTitle("Benchmark Details");
	infoBubble.setBuiltinContent("benchmarkonly");
	infoBubble.selectTab(_bmTab);
}
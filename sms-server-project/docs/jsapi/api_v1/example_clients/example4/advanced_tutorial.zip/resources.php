<?php
$keywords = $_REQUEST['keywords'];
$offset = $_REQUEST['offset'];
$toDisplay = 10;

// separate the keywords
$a_kw = explode('|',$keywords);
foreach($a_kw as $key=>$val){
	if(!$kw){
		$kw = '"'.$val.'"';	
	} else {
		$kw = $kw .' OR "'.$val.'"';	
	}	
}
// check the metadata description and titles only for these keywords
$kw = 'compoundDescription:('.$kw.') AND compoundTitle:('.$kw.')';

// for this example we only want high school level resources
$grades = 'compoundAudience:("high school")';

// only the NASA Earth Science Reviewed Collection
$collections = 'inCollection:oai\:nsdl.org\:crs\:2802786';

// form the query
$query = $kw .' AND '.$grades.' AND '.$collections;	



$url = 'http://ndrsearch.nsdl.org/search?s='.$offset.'&n='.$toDisplay.'&q='.rawurlencode($query);

function parseResults($url){
	if(!$curld = curl_init($url)){
		$o_XML->error = 'Could not initialize session';	
	} else {
		$options = array(CURLOPT_RETURNTRANSFER => true,
							CURLOPT_POST => true,
							CURLOPT_CONNECTTIMEOUT => 30,
							CURLOPT_TIMEOUT => 30);
		curl_setopt_array($curld,$options);
		$s_xml = curl_exec($curld);
		
		try{
			$o_XML = new SimpleXMLElement($s_xml);
		} catch(Exception $e){
		    $o_XML->error = 'Could not parse XML';	
		}
	}
		
	if(!$o_XML->error){
		return $o_XML;		
	}
}

function displayResults($o_XML,$offset,$toDisplay){
	if(($total = $o_XML->SearchResults->resultsInfo->totalNumResults) > 0){
		
		// pagination 
		echo 'Displaying: '.($offset+1);
		if($offset + $toDisplay > $total) {
			echo ' - '.$total;
		} else if($offset + $toDisplay <= $total) {
			echo ' - '.($offset + $toDisplay);
		}
		
		echo ' out of '.$total;
		if($total > 1) {
			echo ' results';
		} else {
			echo ' result';
		}
		
		// previous and next links
		$prev = $offset - $toDisplay;
		$next = $offset + $toDisplay;
	
		if($prev >= 0){
			echo ' <a href="javascript:sendResRequest('.$prev.')">Prev</a>';
		}
		if($prev >= 0 && $next < $total){
			echo ' | ';
		}
		if($next < $total){
			echo ' <a href="javascript:sendResRequest('.$next.')">Next</a>';
		}
		
		// display the records
		$records = $o_XML->SearchResults->results;	
		foreach($records->document as $index=>$item){
			// pick a title - we'll use the first one
			$a_titles = explode(' ~^ ',$item->fields->compoundTitle);
			$a_descriptions = explode(' ~^ ',$item->fields->compoundDescription);
			$s_link = $item->header->resourceIdentifier;
			echo '<p><a href="'.$s_link.'">'.$a_titles[0].'</a><br/>'.$a_descriptions[0].'</p>';
		}	
	} else {
		echo '<p>There are no related resources for this benchmark.</p>';
	}
}

$xml = parseResults($url);
displayResults($xml,$offset,$toDisplay);
?>
SMSEvent.addListener(StrandMap,"onload", setUpStrandMap);

function setUpStrandMap() {
	StrandMap.enableMisconceptions(true);
	infoBubble = StrandMap.getInfoBubble();	
	SMSEvent.addListener(StrandMap,"onbenchmarkselect",onBenchmarkSelect);
	
	
	// Create the 'Resources' tab and set it's handler:
	resourcesTab = new InfoBubbleTab('Related Resources');
	infoBubble.addTab(resourcesTab);
	SMSEvent.addListener(StrandMap,"onbenchmarkselect",resourcesTabCallback);
	
	infoBubble.addBuiltinTab("nses","NSES Standards");
	infoBubble.addBuiltinTab("relatedbenchmarks","Related Benchmarks");
	
	createBreadcrumb();
}
function onBenchmarkSelect() {
	infoBubble.setTitle("Benchmark Details");
	infoBubble.setBuiltinContent("benchmarkonly");
	infoBubble.selectTab(resourcesTab);
}

function resourcesTabCallback() {	
	resourcesTab.setContent('Loading Resources...');
	sendResRequest();
}

function createBreadcrumb(){
	var gradeId = StrandMap.getMapId();
	var myUrl = 'http://strandmaps.nsdl.org/cms1-2/jsapi/json?callBack=getParentMap&Format=SMS-JSON&ObjectID='+gradeId;
	var mapScriptReq = document.createElement( 'script' );
	mapScriptReq.src = myUrl;
	// Insert the script in the document head, which executes the callback getParentMap()
	document.getElementsByTagName('head')[0].appendChild( mapScriptReq );	
}

function getParentMap(jsonResponse){
	var relations = jsonResponse['SMS-CSIP'].QueryResponse.SMS.Record.itemRecord.Data.InternalRelationship.CatalogID;
	if(relations.RelationType == 'is part of' && relations.CatalogNumber.search('MAP') != -1 ){
		var parentMapID = relations.CatalogNumber;
	}	
	
	var myUrl = 'http://strandmaps.nsdl.org/cms1-2/jsapi/json?callBack=getParentMapName&Format=SMS-JSON&ObjectID='+parentMapID;
	var mapScriptReq = document.createElement( 'script' );
	mapScriptReq.src = myUrl;
	// Insert the script in the document head, which executes the callback getParentMap()
	document.getElementsByTagName('head')[0].appendChild( mapScriptReq );	
}

function getParentMapName(jsonResponse){
	var name = jsonResponse['SMS-CSIP'].QueryResponse.SMS.Record.itemRecord.Data.Name;	
	var title = name + ' Map > Grades 9-12';
	$('smsMapName').update(title);
	document.title = title;
}
function sendResRequest(offset){
	if(!offset){
		offset = 0;	
	}
	var json = StrandMap.getSelectedBenchmarkRecordJson();
	var id = StrandMap.getSelectedBenchmarkId();	
		
	<!-- // get the keywords for this benchmark //-->
	var kwArray = json.itemRecord.Data.Keywords.keyword;
	for(var i=0; i< kwArray.length; i++){
		if(i == 0){
			var keywords = kwArray[i];
		} else if(i == kwArray.length-1){
			keywords += '|' + kwArray[i];
		} else {
			keywords += '|' + kwArray[i];
		}
	}
		
	var reqUrl = "resources.php?keywords="+ keywords+ "&offset="+offset;
	
	new Ajax.Request(
		reqUrl, 
		{
			method: 'post', 			
			onSuccess: function (response) {
				var c;
				if(response.responseText){
					resourcesTab.setContent(response.responseText);
				}
			}
	});
}